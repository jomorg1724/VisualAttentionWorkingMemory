def recorded_forward(self,images,task,return_details=False,attention_bias=None,record=False,lesion=None):
    if images.ndim!=5 or images.shape[2] not in (1,3) or tuple(images.shape[-2:])!=(100,100):
        raise ValueError('Need a native RGB/grayscale100x100 movie')
    b,t=images.shape[:2]
    rgb=images.expand(-1,-1,3,-1,-1) if images.shape[2]==1 else images
    gray=rgb.mean(2,keepdim=True)
    # Fixed comparisons have no learned parameters. They are computed once
    # per movie; every lag is causal and first-frame startup repeats frame0.
    costs,valid=self.motion(gray)
    corr=costs.reshape(-1,1,9,9)
    refined=(corr+.1*self.refine(corr)).reshape(b,t,3,100,81)
    tau=self.log_temperature.exp().clamp(.015,.2)
    pop=(refined/tau[None,None,:,None,None]).softmax(-1)
    reference,reference_conf=causal_average(pop,valid,8,8)
    observation,observation_conf=causal_average(pop,valid,4,0)
    confidence=(reference_conf*observation_conf).clamp_min(0).sqrt()
    difference=(observation-reference).abs()
    # Compare at each location BEFORE attention pools locations. These
    # uncompressed channels share exactly the same alpha as visual values.
    local_comparison=torch.cat((
        (10*reference*confidence[...,None]).transpose(2,3).flatten(3),
        (10*observation*confidence[...,None]).transpose(2,3).flatten(3),
        (10*difference*confidence[...,None]).transpose(2,3).flatten(3),
        (difference.sum(-1)*confidence).transpose(2,3),
        ((1-F.cosine_similarity(reference,observation,dim=-1))*confidence).transpose(2,3)),dim=-1)
    displacement=torch.einsum('btlsk,kd->btlsd',pop,self.motion.offsets)
    velocity=displacement/gray.new_tensor([1.,2.,4.])[None,None,:,None,None]
    app=self.appearance((rgb-.5).reshape(b*t,3,100,100)).reshape(b,t,32,100).transpose(2,3)
    means=F.avg_pool2d((rgb-.5).reshape(b*t,3,100,100),10).reshape(b,t,3,100).transpose(2,3)
    energy=F.avg_pool2d((gray-.5).square().reshape(b*t,1,100,100),10).reshape(b,t,100)
    raw=torch.cat((means,energy.sqrt()[...,None]),-1)
    trace=pop.new_full((b,3,100,81),1/81)
    field=pop.new_zeros(b,self.width,10,10); cls=pop.new_zeros(b,self.width)
    history=[]; gate_history=[]; errors=[]; previous_flow=None
    recordings={k:[] for k in ("appearance","fusion","spatial","cls","comparison","probabilities")}
    comparison_memory=pop.new_zeros(b,self.comparison_width)
    for step in range(t):
        if step:
            prediction=warp(gray[:,step-1],previous_flow)
            mse=F.avg_pool2d((prediction-gray[:,step]).square(),10).flatten(1)
            denominator=(.5*(energy[:,step-1]+energy[:,step])).clamp_min(1e-4)
            error=mse/denominator
            # Pixel-derived reliability only; no event or phase metadata.
            weight=(energy[:,step-1]*energy[:,step]).sqrt()
            weight=weight/(weight+1e-4)
            errors.append((error*weight).mean())
        else:
            error=energy[:,step]*0
        difference=(pop[:,step]-trace).abs().sum(-1).transpose(1,2)
        motion_features=(10*pop[:,step]*valid[:,step,...,None]).transpose(1,2).flatten(2)
        features=torch.cat((app[:,step],raw[:,step],motion_features,
            valid[:,step].transpose(1,2),difference,
            velocity[:,step].transpose(1,2).flatten(2),error[...,None]),-1)
        visual=self.fusion(features)+self.position
        old=field.flatten(2).transpose(1,2)
        key=self.key(self.key_norm(visual)+self.memory_norm(old))
        query=self.query(self.query_norm(cls+self.cls_token))
        key=F.normalize(key,dim=-1,eps=1e-6)
        query=F.normalize(query,dim=-1,eps=1e-6)
        attention_scale=1+15*self.attention_scale_logit.sigmoid()
        logits=attention_scale*(key*query[:,None]).sum(-1)
        if attention_bias is not None:
            bias=attention_bias[:,step] if attention_bias.ndim==3 else attention_bias[step] if attention_bias.ndim==2 else attention_bias
            if bias.shape not in ((100,),(b,100)): raise ValueError('Bad analysis intervention shape')
            logits=logits+bias
        alpha=logits.softmax(-1)
        value=self.value(visual)+self.memory_value(old)
        value=value+self.ffn(value)
        # The SAME alpha routes all appearance/motion channels to the CLS
        # and modulates spatial writes. No global comparison bypass exists.
        selected=(alpha[...,None]*value).sum(1)
        selected_comparison=(alpha[...,None]*local_comparison[:,step]).sum(1)
        comparison_memory=.8*comparison_memory+.2*selected_comparison
        write_attention=(alpha/(alpha+1/alpha.shape[-1])).reshape(b,1,10,10)
        field,spatial_stats=self.spatial(value.transpose(1,2).reshape(b,self.width,10,10),field,write_attention,return_details)
        cls,cls_stats=self.cls(selected,cls,return_details)
        if lesion is not None and step==lesion['time']:
            if lesion['state']=='spatial':field=field*lesion['gain']
            elif lesion['state']=='cls':cls=cls*lesion['gain']
            elif lesion['state']=='comparison':comparison_memory=comparison_memory*lesion['gain']
            else:raise ValueError(lesion)
        if record:
            for name,v in [('appearance',app[:,step]),('fusion',visual),('spatial',field.flatten(2).transpose(1,2)),('cls',cls),('comparison',comparison_memory)]:
                recordings[name].append(v.detach().cpu())
            recordings['probabilities'].append(self.heads[task](self.readout(torch.cat((cls,comparison_memory),-1))).softmax(-1).detach().cpu())
        if return_details: gate_history.append(torch.cat((spatial_stats,cls_stats)))
        trace=trace+self.trace_rate.sigmoid()*valid[:,step,...,None]*(pop[:,step]-trace)
        previous_flow=velocity[:,step].mean(1).transpose(1,2).reshape(b,2,10,10)
        if return_details: history.append(alpha)
    output=self.heads[task](self.readout(torch.cat((cls,comparison_memory),-1)))
    prediction_loss=torch.stack(errors).mean() if errors else output.sum()*0
    if return_details:
        return output,dict(attention=torch.stack(history,1).reshape(b,t,10,10),
            recordings={k:torch.stack(v,1) for k,v in recordings.items()} if record else {},
            prediction_loss=prediction_loss,cls=cls,temperature=tau,comparison_memory=comparison_memory,
            gate_statistics=torch.stack(gate_history).mean(0),attention_scale=attention_scale)
    return output
