# KDA results graphics
Open SecondPass/KDA_paper/figures/index.html for the offline gallery, or KDA_results_atlas.pdf in that folder. All 29 figures are included as PNG, SVG and PDF, with CSVs and source records. The repository-relative structure preserves source links. No weights or per-trial spatial maps are included.
